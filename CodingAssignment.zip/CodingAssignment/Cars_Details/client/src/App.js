import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import CarList from './components/CarList';
import AddCarForm from './components/AddCarForm';
import './App.css';

function App() {
  return (
    <Router>
      <div className="App">
        <h1>Car List</h1>
        <Routes>
          <Route path="/" element={<CarList />} />
          <Route path="/add" element={<AddCarForm />} />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
