import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

function AddCarForm() {
  const [name, setName] = useState('');
  const [brand, setBrand] = useState('');
  const [colour, setColour] = useState('');
  const [type, setType] = useState('');
  const [error, setError] = useState(null);

  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    setError(null);

    if (!name || !brand || !colour || !type) {
      setError('All fields are required!');
      return;
    }

    const newCar = { name, brand, colour, type };

    axios.post('http://localhost:5000/api/cars', newCar)
      .then(response => {
        navigate('/');
      })
      .catch(error => {
        setError('Error adding car');
      });
  };

  return (
    <div>
      <h2>Add New Car</h2>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      <form onSubmit={handleSubmit}>
        <label>Car Name:</label>
        <input type="text" value={name} onChange={(e) => setName(e.target.value)} />
        
        <label>Brand:</label>
        <input type="text" value={brand} onChange={(e) => setBrand(e.target.value)} />
        
        <label>Colour:</label>
        <input type="text" value={colour} onChange={(e) => setColour(e.target.value)} />
        
        <label>Type:</label>
        <select value={type} onChange={(e) => setType(e.target.value)}>
          <option value='1'>Select</option>
          <option value="EV">EV</option>
          <option value="Manual">Manual</option>
          <option value="Automatic">Automatic</option>
        </select>
        
        <button type="submit">Add Car</button>
      </form>
    </div>
  );
}

export default AddCarForm;
