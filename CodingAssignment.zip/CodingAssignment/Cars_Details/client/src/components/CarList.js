import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Link } from 'react-router-dom';

function CarList() {
  const [cars, setCars] = useState([]);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios.get('http://localhost:5000/api/cars')
      .then(response => {
        setCars(response.data);
      })
      .catch(error => {
        setError('Error fetching cars data');
      });
  }, []);

  return (
    <div>
      <h2>Available Cars</h2>
      {error && <p>{error}</p>}
      <div className="car-cards">
        {cars.map((car, index) => (
          <div className="car-card" key={index}>
            <h3>{car.name}</h3>
            <p><strong>Brand:</strong> {car.brand}</p>
            <p><strong>Colour:</strong> {car.colour}</p>
            <p><strong>Type:</strong> {car.type}</p>
          </div>
        ))}
      </div>
      <Link to="/add">Add New Car</Link>
    </div>
  );
}

export default CarList;
