let cars = [
    { id: 1, name: 'Tesla Model S', brand: 'Tesla', colour: 'Red', type: 'EV' },
    { id: 2, name: 'Honda Civic', brand: 'Honda', colour: 'Blue', type: 'Manual' }
  ];
  
  const getCars = (req, res) => {
    res.json(cars);
  };
  
  const addCar = (req, res) => {
    const { name, brand, colour, type } = req.body;
  
    if (!name || !brand || !colour || !type) {
      return res.status(400).json({ message: 'All fields are required.' });
    }
  
    const newCar = {
      id: cars.length + 1,
      name,
      brand,
      colour,
      type
    };
  
    cars.push(newCar);
    res.status(201).json(newCar);
  };
  
  module.exports = { getCars, addCar };